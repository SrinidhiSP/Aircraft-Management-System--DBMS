<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
  $Username = test_input($_POST["UName"]);
  $Upwd = test_input($_POST["Upwd"]);
 /* echo "Username is ".$Username;
  echo "User password is ".$Upwd;
  
  if ($Username === "root") {
  	echo "alert('You entered username root');";
  }*/
$con=mysqli_connect("localhost","root","","air_mgmt");

$result="insert into signin (username, pwssd) values ('".$Username."', '".$Upwd."')";
$con->query($result);
if ($Upwd === "root123") {
  	header('Location: /website/index.html');
  }
  else {
  	echo "Invalid username/password";
  } 
/*$con=mysqli_connect("localhost","root","","air_mgmt");

$result="insert into signin (username, pwssd) values ('".$Username."', '".$Upwd."')";
// $result="insert into signin (username, pwssd) values ('ABC','DEF');";
echo "\n".$result;
if($con->query($result) ===TRUE){
  header('Location: /website/index.html');
	/* echo "<script>
alert('Inserted data successfully');
window.location.href='cd.html';
</script>"; 
}
else {
	echo "Insert failed";
}
 
}*/
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>