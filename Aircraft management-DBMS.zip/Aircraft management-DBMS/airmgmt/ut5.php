<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
  $Username = test_input($_POST["airname"]);
  $Upwd = test_input($_POST["aid"]);
  //$Username1 = test_input($_POST["org"]);
  $Upwd1 = test_input($_POST["serv"]);
  $Username2 = test_input($_POST["type"]);
  $Upwd2 = test_input($_POST["date1"]);
  $Username3 = test_input($_POST["date2"]);
  $Upwd3 = test_input($_POST["spec"]);
  //$U1=$Username3-$Upwd2;
  $U1 = test_input($_POST["dur"]);
  //$U1=$Username3-$Upwd2;
  echo "Username is ".$Username;
  echo "User password is ".$Upwd;
  
  if ($Upwd === "ind112") {
  	$Username1 = "India";
  }
  else 
  { $Username1="unknown";}

/* if ($Username === "root" and $Upwd === "root123") {
  	header('Location: /website/aircraft.html');
  }
  else {
  	echo "Invalid username/password";
  } */
$con=mysqli_connect("localhost","root","","air_mgmt");

$result="insert into aircraft (name,air_id,origin,serving,type,launch,servend,speciality,duration) values ('".$Username."', '".$Upwd."','".$Username1."', '".$Upwd1."','".$Username2."', '".$Upwd2."','".$Username3."', '".$Upwd3."','".$U1."')";
echo "\n".$result;
if($con->query($result) ===TRUE){
  header('Location: /website/aircraft.html');
	echo "<script>
alert('Inserted data successfully');
</script>"; 
}
else {
	echo "Insert failed";
}
 
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}/* <tr>
    <td>SERVICE DURATION :</td>
    <td><input type="number" name="dur" ></td>
   </tr>*/
//window.location.href='cd.html';
?>
