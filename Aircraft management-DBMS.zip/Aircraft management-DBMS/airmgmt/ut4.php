<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
  $Username = test_input($_POST["usn"]);
  $Upwd = test_input($_POST["name"]);
  $Username1 = test_input($_POST["pass"]);
  $Upwd1 = test_input($_POST["myEmail"]);
  
  echo "Username is ".$Username;
  echo "User password is ".$Upwd;
  
  if ($Username === "root") {
  	echo "alert('You entered username root');";
  }

/* if ($Username === "root" and $Upwd === "root123") {
  	header('Location: /website/aircraft.html');
  }
  else {
  	echo "Invalid username/password";
  } */
$con=mysqli_connect("localhost","root","","air_mgmt");

$result="insert into register (usn,name,pass,myEmail) values ('".$Username."', '".$Upwd."','".$Username1."', '".$Upwd1."')";
// $result="insert into signin (username, pwssd) values ('ABC','DEF');";
echo "\n".$result;
if($con->query($result) ===TRUE){
  header('Location: /website/index.html');
	/* echo "<script>
alert('Inserted data successfully');
window.location.href='cd.html';
</script>"; */
}
else {
	echo "Insert failed";
}
 
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>