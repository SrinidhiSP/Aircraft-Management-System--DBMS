<? php
// $Username=$_POST['Username'];
// $Password=$_POST['Password'];
$conn=mysqli_connect('localhost','root','','air_mgmt');
/* if($conn->connect_error){
die('Connection Failed'.$conn->connect_error);
}else{
$stmt=$conn->prepare("INSERT INTO signin(username,pwssd) VALUES('$Username','$Password')";
$stmt->execute();
echo "success";
$stmt->close();
$conn->close(); */
if ($conn) {
	echo "Success";
}
else {
	echo "Connection Failed";
}
?>
