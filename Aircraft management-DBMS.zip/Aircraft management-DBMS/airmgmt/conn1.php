<?php

 $id ="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
  $id = test_input($_POST["gg"]);
 
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
$con=mysqli_connect("localhost","root","","air_mgmt");

$result="insert into signin (username, pwssd) values ('Arun', 'arun123')";
if($con->query($result) ===TRUE){
	echo "<script>
alert('Inserted data successfully');
window.location.href='cd.html';
</script>";
}
else {
    echo "Error: " . $result . "<br>" . $con->error;
}

$con->close();


?>