<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "air_mgmt";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT name,air_id,origin,serving,type FROM aircraft";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "name: " . $row["name"]." - aircraft_id: " . $row["air_id"]. " - origin:" . $row["origin"]."<br>  Country serving:". $row["serving"]." - type:". $row["type"]."<br><br><br>";
    }
} else {
    echo "0 results";
}
/*echo "<script>
alert('Inserted data successfully');
window.location.href='website/index.html';
</script>";*/
$conn->close();
?>
