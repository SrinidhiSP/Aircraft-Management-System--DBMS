<?php
$username=filter_input(INPUT_POST,'Username');
$password=filter_input(INPUT_POST,'Password');
$host="localhost";
$dbUsername="root";
$dbPassword="";
$dbName="air_mgmt";
$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
if (mysqli_connect_error()){
	die('Connect Error ('.mysqli_connect_errno().')'
	.mysqli_connect_error());
	}
else{
	$sql="INSERT INTO signin (username,pwssd) VALUES ('$username','$password');";
	if($conn->query($sql)){
	echo "new record inserted";
	}
	else{
	echo "error";
	}
	$conn->close();
$>