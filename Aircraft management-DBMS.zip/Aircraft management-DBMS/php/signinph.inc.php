<?php

$dbServername="localhost";
$dbUsername="root";
$dbPassword="";
$dbName="signin";
$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
>